package dao;

import model.Filme;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class FilmeDAO {
    
    private Connection conn;
    private PreparedStatement stmt;
    private Statement st;
    private ResultSet rs;
    private ArrayList<Filme> lista = new ArrayList<>();
    
    public FilmeDAO(){
        conn = new ConnectionFactory().getConexao();
    }
    
    public void inserir(Filme filme){
        String sql = "INSERT INTO filme (filme_id, titulo, descricao, ano_de_lancamento, idioma_id,idioma_original_id,duracacao_da_locacao, preco_da_locacao, duracao_do_filme, custo_de_substituicao,classificacao, recursos_especiais) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
        try{
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, filme.getFilme_id());
            stmt.setString(2, filme.getTitulo());
            stmt.setString(3, filme.getDescricao());
            stmt.setInt(4, filme.getAno_de_lancamento());
            stmt.setInt(5, filme.getIdioma_id());
            stmt.setInt(6, filme.getIdioma_original_id());
            stmt.setInt(7, filme.getDuracao_da_locacao());
            stmt.setDouble(8, filme.getPreco_da_locacao());
            stmt.setInt(9, filme.getDuracao_do_filme());
            stmt.setDouble(10, filme.getCusto_de_substituicao());
            stmt.setString(11, filme.getClassificacao());
            stmt.setString(12, filme.getRecursos_especiais());
            stmt.execute();
            stmt.close();
        }catch(Exception erro){
            throw new RuntimeException("Erro2: "+ erro);
        }
    }
    
    public void alterar(Filme filme){
        String sql = "UPDATE filme SET titulo = ?, descricao = ?, ano_de_lancamento = ?, idioma_id = ?,idioma_original_id = ?, duracacao_da_locacao = ?, preco_da_locacao = ?, duracao_do_filme = ?, custo_de_substituicao = ?,classificacao = ?, recursos_especiais = ? WHERE filme_id = ?";
        try{
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, filme.getTitulo());
            stmt.setString(2, filme.getDescricao());
            stmt.setInt(3, filme.getAno_de_lancamento());
            stmt.setInt(4, filme.getIdioma_id());
            stmt.setInt(5, filme.getIdioma_original_id());
            stmt.setInt(6, filme.getDuracao_da_locacao());
            stmt.setDouble(7, filme.getPreco_da_locacao());
            stmt.setInt(8, filme.getDuracao_do_filme());
            stmt.setDouble(9, filme.getCusto_de_substituicao());
            stmt.setString(10, filme.getClassificacao());
            stmt.setString(11, filme.getRecursos_especiais());
            stmt.setInt(12, filme.getFilme_id());
            stmt.execute();
            stmt.close();
        }catch(Exception erro){
            throw new RuntimeException("Erro3: "+ erro);
        }
    }
    
    public void excluir(int valor){
        String sql = "DELETE FROM filme WHERE filme_id = "+valor;
        try{
            st = conn.createStatement();
            st.execute(sql);
            st.close();
        }catch(Exception erro){
            throw new RuntimeException("Erro4: "+ erro);
        }
    }
    
    public ArrayList<Filme> listaTodos(){
        String sql = "SELECT * FROM filme";
        try{
            st = conn.createStatement();
            rs = st.executeQuery(sql);
            while(rs.next()){
                Filme filme = new Filme();
                filme.setFilme_id(rs.getInt("filme_id"));
                filme.setTitulo(rs.getString("titulo"));
                filme.setDescricao(rs.getString("descricao"));
                filme.setAno_de_lancamento(rs.getInt("ano_de_lancamento"));
                filme.setIdioma_id(rs.getInt("idioma_id"));
                filme.setIdioma_original_id(rs.getInt("idioma_original_id"));
                filme.setDuracao_da_locacao(rs.getInt("duracao_da_locacao"));
                filme.setPreco_da_locacao(rs.getDouble("preco_da_locacao"));
                filme.setDuracao_do_filme(rs.getInt("duracao_do_filme"));
                filme.setCusto_de_substituicao(rs.getDouble("custo_de_substituicao"));
                filme.setClassificacao(rs.getString("classificacao"));
                filme.setRecursos_especiais(rs.getString("recursos_especiais"));
                lista.add(filme);                
            }
        }catch(Exception erro){
            throw new RuntimeException("Erro 5: " + erro);
        }
        return lista;
    }
    
    public ArrayList<Filme> listaTodosNome(String valor){
        String sql = "SELECT * FROM filme WHERE titulo Like '%"+valor+"%' ";
        try{
            st = conn.createStatement();
            rs = st.executeQuery(sql);
            while(rs.next()){
                Filme filme = new Filme();
                filme.setFilme_id(rs.getInt("filme_id"));
                filme.setTitulo(rs.getString("titulo"));
                filme.setDescricao(rs.getString("descricao"));
                filme.setAno_de_lancamento(rs.getInt("ano_de_lancamento"));
                filme.setIdioma_id(rs.getInt("idioma_id"));
                filme.setIdioma_original_id(rs.getInt("idioma_original_id"));
                filme.setDuracao_da_locacao(rs.getInt("duracao_da_locacao"));
                filme.setPreco_da_locacao(rs.getDouble("preco_da_locacao"));
                filme.setDuracao_do_filme(rs.getInt("duracao_do_filme"));
                filme.setCusto_de_substituicao(rs.getDouble("custo_de_substituicao"));
                filme.setClassificacao(rs.getString("classificacao"));
                filme.setRecursos_especiais(rs.getString("recursos_especiais"));
                lista.add(filme);                
            }
        }catch(Exception erro){
            throw new RuntimeException("Erro 5: " + erro);
        }
        return lista;
    }
}
