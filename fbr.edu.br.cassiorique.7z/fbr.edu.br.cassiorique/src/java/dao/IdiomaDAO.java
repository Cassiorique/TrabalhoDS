package dao;

import model.Idioma;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class IdiomaDAO {
    
    private Connection conn;
    private PreparedStatement stmt;
    private Statement st;
    private ResultSet rs;
    private ArrayList<Idioma> lista = new ArrayList<>();
    
    public IdiomaDAO(){
        conn = new ConnectionFactory().getConexao();
    }
    
    public void inserir(Idioma idioma){
        String sql = "INSERT INTO idioma (nome) VALUES (?)";
        try{
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, idioma.getNome());
            stmt.execute();
            stmt.close();
        }catch(Exception erro){
            throw new RuntimeException("Erro2: "+ erro);
        }
    }
    
    public void alterar(Idioma idioma){
        String sql = "UPDATE idioma SET nome = ? WHERE idioma_id = ?";
        try{
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, idioma.getNome());
            stmt.setInt(2, idioma.getIdioma_id());
            stmt.execute();
            stmt.close();
        }catch(Exception erro){
            throw new RuntimeException("Erro3: "+ erro);
        }
    }
    
    public void excluir(int valor){
        String sql = "DELETE FROM idioma WHERE idioma_id = "+valor;
        try{
            st = conn.createStatement();
            st.execute(sql);
            st.close();
        }catch(Exception erro){
            throw new RuntimeException("Erro4: "+ erro);
        }
    }
    
    public ArrayList<Idioma> listaTodos(){
        String sql = "SELECT * FROM idioma";
        try{
            st = conn.createStatement();
            rs = st.executeQuery(sql);
            while(rs.next()){
                Idioma idioma = new Idioma();
                idioma.setIdioma_id(rs.getInt("idioma_id"));
                idioma.setNome(rs.getString("nome"));
                lista.add(idioma);                
            }
        }catch(Exception erro){
            throw new RuntimeException("Erro 5: " + erro);
        }
        return lista;
    }
    
    public ArrayList<Idioma> listaTodosNome(String valor){
        String sql = "SELECT * FROM idioma WHERE nome Like '%"+valor+"%' ";
        try{
            st = conn.createStatement();
            rs = st.executeQuery(sql);
            while(rs.next()){
                Idioma idioma = new Idioma();
                idioma.setIdioma_id(rs.getInt("idioma_id"));
                idioma.setNome(rs.getString("nome"));
                lista.add(idioma);                
            }
        }catch(Exception erro){
            throw new RuntimeException("Erro 5: " + erro);
        }
        return lista;
    }
}
