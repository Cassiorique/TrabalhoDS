package model;


public class Filme {
    private int filme_id;
    private String titulo;
    private String descricao;
    private int ano_de_lancamento;
    private int idioma_id;
    private int idioma_original_id;
    private int duracao_da_locacao;
    private double preco_da_locacao;
    private int duracao_do_filme;
    private double custo_de_substituicao;
    private String classificacao;
    private String recursos_especiais;

    public int getIdioma_original_id() {
        return idioma_original_id;
    }

    public void setIdioma_original_id(int idioma_original_id) {
        this.idioma_original_id = idioma_original_id;
    }

    public int getFilme_id() {
        return filme_id;
    }

    public void setFilme_id(int filme_id) {
        this.filme_id = filme_id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public int getAno_de_lancamento() {
        return ano_de_lancamento;
    }

    public void setAno_de_lancamento(int ano_de_lancamento) {
        this.ano_de_lancamento = ano_de_lancamento;
    }

    public int getIdioma_id() {
        return idioma_id;
    }

    public void setIdioma_id(int idioma_id) {
        this.idioma_id = idioma_id;
    }

    public int getDuracao_da_locacao() {
        return duracao_da_locacao;
    }

    public void setDuracao_da_locacao(int duracao_da_locacao) {
        this.duracao_da_locacao = duracao_da_locacao;
    }

    public double getPreco_da_locacao() {
        return preco_da_locacao;
    }

    public void setPreco_da_locacao(double preco_da_locacao) {
        this.preco_da_locacao = preco_da_locacao;
    }

    public int getDuracao_do_filme() {
        return duracao_do_filme;
    }

    public void setDuracao_do_filme(int duracao_do_filme) {
        this.duracao_do_filme = duracao_do_filme;
    }

    public double getCusto_de_substituicao() {
        return custo_de_substituicao;
    }

    public void setCusto_de_substituicao(double custo_de_substituicao) {
        this.custo_de_substituicao = custo_de_substituicao;
    }

    public String getClassificacao() {
        return classificacao;
    }

    public void setClassificacao(String classificacao) {
        this.classificacao = classificacao;
    }

    public String getRecursos_especiais() {
        return recursos_especiais;
    }

    public void setRecursos_especiais(String recursos_especiais) {
        this.recursos_especiais = recursos_especiais;
    }
    
    
}
